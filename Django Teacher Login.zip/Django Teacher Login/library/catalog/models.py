from operator import mod
from django.urls import reverse
from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Teacher(models.Model):
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    
    phone = models.IntegerField()
    sex = models.CharField(max_length=10) 
    subject = models.CharField(max_length=30)
    
    def __str__(self):
        return f" Name: {self.first_name} {self.last_name}  , Phone number : {self.phone} , Sex : {self.sex} , Subject : {self.subject}"