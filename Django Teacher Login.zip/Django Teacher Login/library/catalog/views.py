from distutils.errors import LibError
from distutils.log import Log
import imp
from multiprocessing import context
from django.shortcuts import render
from django.http import HttpResponse
from django.urls import reverse_lazy
from django.views.generic import CreateView, DetailView, ListView
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.forms import UserCreationForm


# Create your views here

def index (request) :
    return render(request, 'catalog/index.html')   
    

@login_required  
def my_view(request):
    return render(request, 'catalog/my_view.html')



class SignUpView(CreateView):
  
    form_class = UserCreationForm
    success_url = reverse_lazy('library/templates/login') 
    template_name = 'catalog/signup.html'


## Teachers

import re
from django.shortcuts import render
from django.urls import reverse,reverse_lazy
from django.views.generic import TemplateView, FormView, CreateView, ListView, DetailView, UpdateView, DeleteView
from catalog.models import Teacher
from catalog.forms import ContactForm
# Create your views here.



class HomeView(TemplateView):
    template_name = 'catalog/home.html'
    
class ThankyouView(TemplateView):
    template_name = 'catalog/thankyou.html'
    
    
class TeacherCreateView(LoginRequiredMixin, CreateView):
    model = Teacher
    # mode_form.html
    # .save()
    fields = "__all__"
    success_url = reverse_lazy('catalog:thankyou') 
    
    
    
class TeacherListView(LoginRequiredMixin ,ListView):
    #model_list.html
    model = Teacher
    queryset = Teacher.objects.order_by('first_name')
    context_object_name = "teacher_list"
    
    
#class TeachersView(ListView):
# context_object_name = "teachersview"    
    
    
class TeacherDetailView(DetailView):
    #return only one model entry
    #model_detail.html
    model = Teacher    
    # PK --> {{teacher}}
    
    
class TeacherUpdateView(UpdateView):
    model = Teacher
    fields = "__all__"
    success_url = reverse_lazy('catalog:list_teacher')
    
class HomePageView(TemplateView):
    template_name = 'catalog/homepage.html'
    
    
class TeacherDeleteView(DeleteView):
    #form --> Confirm Delete Button
    # Default template name:
    # model_confirm_delete.html

    model = Teacher
    success_url = reverse_lazy('catalog:list_teacher')
    
    
class ContactFormView(FormView):
    form_class = ContactForm
    template_name = 'catalog/contact.html'
    
    #URL not a template.html
    success_url = reverse_lazy('catalog:thankyou')
    
    #what to do with form
    def form_valid(self,form):
        
        print(form.cleaned_data)
        return super().form_valid(form)