import imp
from django.contrib import admin
from .models import Teacher


#admin adminpassword

#dhanvy152 aswamedhan
# Register your models here.

admin.site.register(Teacher)
