from django.urls import path
from . import views
from .views import HomePageView,  TeacherCreateView, ThankyouView, ContactFormView,TeacherListView, TeacherDetailView, TeacherUpdateView, TeacherDeleteView
app_name = 'catalog'
#domain.com/catalog/teaher_detail/1
urlpatterns = [
    #path expects a function
    path('', views.index, name='index'),
    path('my_view/', views.my_view, name= 'my_view'),
    path('signup', views.SignUpView.as_view(), name='signup'),
    path('thankyou/',ThankyouView.as_view(), name='thankyou'),
    path('contact/', ContactFormView.as_view(), name='contact'),
    path('create_teacher/', TeacherCreateView.as_view(), name='create_teacher'),
    path('list_teacher', TeacherListView.as_view(), name='list_teacher'),
    path('teacher_detail/<int:pk>', TeacherDetailView.as_view(), name='detail_teacher'),
    #path('teachersview/<int:pk>', TeachersView.as_view(), name='teachersview'),
    path('update_teacher/<int:pk>', TeacherUpdateView.as_view(), name='update_teacher'),
    path('delete_teacher/<int:pk>',TeacherDeleteView.as_view()),
    path('homepage/', HomePageView.as_view(), name='homepage')
]